import { supabase } from '../supabase';
import { SavedReport } from '../types';

export const reportService = {
  async saveReport(report: SavedReport) {
    const { error } = await supabase.from('reports').upsert(report);
    if (error) throw error;
  },

  async deleteReport(id: string) {
    const { error } = await supabase.from('reports').delete().eq('id', id);
    if (error) throw error;
  },
};
