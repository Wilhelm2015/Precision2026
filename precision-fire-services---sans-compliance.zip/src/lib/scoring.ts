import { Equipment, InspectionRecord, TaskType, EquipmentType } from '../../types';

export interface SiteStats {
  total: number;
  passed: number;
  failed: number;
  pending: number;
  deferredPTCount: number;
  flashFireCount: number;
  vesselFailureCount: number;
  basePercentage: number;
  finalPercentage: number;
  percentage: number; 
  isCompliant: boolean;
}

export function calculateSiteStats(equipment: Equipment[], records: InspectionRecord[], faults: any[] = []): SiteStats {
  const activeAssets = equipment.filter(e => !e.isArchived);
  
  if (activeAssets.length === 0) {
    return {
      total: 0, passed: 0, failed: 0, pending: 0, deferredPTCount: 0, flashFireCount: 0, vesselFailureCount: 0,
      basePercentage: 0, finalPercentage: 0, percentage: 0, isCompliant: false
    };
  }

  const activeFaults = faults.filter(f => f.status === 'Open' && activeAssets.some(a => a.id === f.equipmentId));

  const assetCompliance = activeAssets.map(e => {
    const assetRecords = records.filter(r => {
      const rid = String(r.equipmentId || r.equipment_id || r.asset_id || '').trim();
      const eid = String(e.id || '').trim();
      return rid === eid;
    });
    
    const latestInspection = assetRecords.filter(r => 
      r.taskType === TaskType.INSPECTION || 
      r.taskType === TaskType.MAINTENANCE || 
      (r.task_type === TaskType.INSPECTION || r.task_type === TaskType.MAINTENANCE) ||
      (!r.taskType && !r.task_type && (r.status === 'pass' || r.status === 'fail' || r.status === 'Service Required'))
    ).sort((a, b) => {
      const dateA = new Date(a.date || 0).getTime();
      const dateB = new Date(b.date || 0).getTime();
      if (isNaN(dateA)) return 1;
      if (isNaN(dateB)) return -1;
      return dateB - dateA;
    })[0];
    const latestFlowTest = assetRecords.filter(r => r.taskType === TaskType.FLOW_TEST || r.task_type === TaskType.FLOW_TEST).sort((a, b) => {
      const dateA = new Date(a.date || 0).getTime();
      const dateB = new Date(b.date || 0).getTime();
      if (isNaN(dateA)) return 1;
      if (isNaN(dateB)) return -1;
      return dateB - dateA;
    })[0];
    const latestPressureTest = assetRecords.filter(r => r.taskType === TaskType.PRESSURE_TEST || r.task_type === TaskType.PRESSURE_TEST).sort((a, b) => {
      const dateA = new Date(a.date || 0).getTime();
      const dateB = new Date(b.date || 0).getTime();
      if (isNaN(dateA)) return 1;
      if (isNaN(dateB)) return -1;
      return dateB - dateA;
    })[0];

    const hasOpenFault = activeFaults.some(f => f.equipmentId === e.id);
    
    const status = (latestInspection?.status || '').toLowerCase();
    const flowStatus = (latestFlowTest?.status || '').toLowerCase();
    const ptStatus = (latestPressureTest?.status || '').toLowerCase();

    // Check findings for any failures
    const findings = latestInspection?.findings || {};
    const hasFailedFinding = Object.values(findings).some(val => 
      val === false || 
      (typeof val === 'string' && (
        val.toLowerCase() === 'fail' || 
        val.toLowerCase() === 'failed' || 
        val.toLowerCase() === 'poor' || 
        val.toLowerCase() === 'service required' ||
        val.toLowerCase() === 'no' ||
        val.toLowerCase() === 'negative' ||
        val.toLowerCase() === 'bad' ||
        val.toLowerCase() === 'defective' ||
        val.toLowerCase() === 'not ok' ||
        val.toLowerCase() === 'replace' ||
        val.toLowerCase() === 'damaged'
      ))
    );

    const inspectionPassed = status === 'pass' && !hasFailedFinding;
    const flowPassed = (e.type !== EquipmentType.HOSE_REEL && e.type !== EquipmentType.HYDRANT) || (flowStatus === 'pass');
    const pressurePassed = (e.type !== EquipmentType.EXTINGUISHER && e.type !== EquipmentType.CO2_EXTINGUISHER) || 
                           (!latestPressureTest || ptStatus === 'pass');

    const isCompliant = inspectionPassed && flowPassed && pressurePassed && !hasOpenFault;
    const isFailed = status === 'fail' || status === 'condemned' || 
                     flowStatus === 'fail' || ptStatus === 'fail' ||
                     status === 'service required' || hasFailedFinding;
    
    const isPending = !latestInspection && !latestFlowTest && !latestPressureTest;

    const isFlashFire = (e.manufacturer || '').toLowerCase().trim().includes('flash fire') || 
                   (e.make || '').toLowerCase().trim().includes('flash fire') || 
                   (e.type || '').toLowerCase().trim().includes('flash fire') ||
                   (e.model || '').toLowerCase().trim().includes('flash fire') ||
                   (e.manufacturer || '').toLowerCase().trim().includes('flashfire') || 
                   (e.make || '').toLowerCase().trim().includes('flashfire') ||
                   (e.type || '').toLowerCase().trim().includes('flashfire') ||
                   (e.model || '').toLowerCase().trim().includes('flashfire') ||
                   (e.manufacturer || '').toLowerCase().trim().includes('flash-fire') || 
                   (e.make || '').toLowerCase().trim().includes('flash-fire') ||
                   (e.type || '').toLowerCase().trim().includes('flash-fire') ||
                   (e.model || '').toLowerCase().trim().includes('flash-fire');

    return {
      isCompliant,
      isFailed,
      isPending,
      isCondemned: status === 'condemned',
      isDeferredPT: latestInspection?.pressureTestOption === 'later',
      isFlashFire,
      vesselFailed: latestInspection?.findings?.vessel_condition === false
    };
  });

  const total = activeAssets.length;
  const passed = assetCompliance.filter(c => c.isCompliant).length;
  const failed = assetCompliance.filter(c => c.isFailed).length;
  const pending = assetCompliance.filter(c => c.isPending).length;
  const deferredPTCount = assetCompliance.filter(c => c.isDeferredPT).length;
  const flashFireCount = assetCompliance.filter(c => c.isFlashFire).length;
  const vesselFailureCount = assetCompliance.filter(c => c.vesselFailed).length;

  // Deductions: 2% per failed check, 5% per condemned/flash-fire unit
  // Start at 100%
  let finalPercentage = 100;
  
  // 1. 2% for every FAILED asset (that isn't rectified)
  // Our "failed" count already excludes assets whose LATEST record is a Pass
  finalPercentage -= (failed * 2);
  
  // 2. 5% for Flash Fire and Condemn units
  // Note: Condemned units are likely also in the "failed" count, so we adjust the total deduction
  // to be 5% total for those units (2% base failed + 3% extra for being condemned)
  const condemnedCount = assetCompliance.filter(c => c.isCondemned).length;
  finalPercentage -= (flashFireCount * 5);
  finalPercentage -= (condemnedCount * 3); // 2% was already deducted by 'failed' count
  
  // 3. Open Faults also deduct 2%
  finalPercentage -= (activeFaults.length * 2);
  
  // Base percentage from passed items (Legacy compatibility)
  const basePercentage = total > 0 ? Math.round((passed / total) * 100) : 0;
  
  // Final Score Calculation
  finalPercentage = Math.max(0, Math.floor(finalPercentage));
  console.log(`[SCORING] Final Calculated: ${finalPercentage}% - Total Assets: ${total}, Failed: ${failed}, Flash: ${flashFireCount}, Condemned: ${condemnedCount}, Open Faults: ${activeFaults.length}`);
  
  const isCompliant = total > 0 && finalPercentage >= 100;

  return {
    total, passed, failed, pending, deferredPTCount, flashFireCount, vesselFailureCount,
    basePercentage, 
    finalPercentage, 
    percentage: finalPercentage, 
    isCompliant
  };
}
