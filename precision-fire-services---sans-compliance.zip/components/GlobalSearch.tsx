
import React, { useState, useEffect, useRef } from 'react';
import { syncService } from '../services/registryService';
import { Client, Equipment, InspectionRecord, FaultReport } from '../types';

interface GlobalSearchProps {
  onResults: (data: { clients: Client[], equipment: Equipment[], records: InspectionRecord[], faults: FaultReport[] }) => void;
  onClose: () => void;
}

const GlobalSearch: React.FC<GlobalSearchProps> = ({ onResults, onClose }) => {
  const [term, setTerm] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!term.trim()) return;

    setIsSearching(true);
    setError(null);
    try {
      const results = await syncService.searchGlobalRegistry(term);
      if (results) {
        onResults(results);
        onClose();
      } else {
        setError("No sites found matching your search.");
      }
    } catch (err: any) {
      setError("Search failed. Please check your connection.");
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-slate-900/80 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="w-full max-w-2xl bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-white/20">
        <div className="p-8 space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Global Registry Search</h2>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Search the entire cloud archive</p>
            </div>
            <button onClick={onClose} className="p-3 bg-slate-50 text-slate-400 rounded-2xl hover:bg-slate-100 transition-all">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <form onSubmit={handleSearch} className="relative">
            <input 
              ref={inputRef}
              type="text" 
              placeholder="Search Site Name, Building, or Address..." 
              value={term} 
              onChange={e => setTerm(e.target.value)} 
              className="w-full bg-slate-50 border-4 border-slate-100 rounded-[2rem] px-14 py-6 outline-none focus:border-red-500 transition-all font-bold text-lg text-slate-900"
            />
            <svg className="w-6 h-6 text-slate-400 absolute left-6 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            
            <button 
              type="submit"
              disabled={isSearching || !term.trim()}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-red-600 text-white px-8 py-3 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl hover:bg-red-700 transition-all disabled:opacity-50 disabled:hover:bg-red-600"
            >
              {isSearching ? 'Searching...' : 'Search'}
            </button>
          </form>

          {error && (
            <div className="p-6 bg-red-50 rounded-3xl border-2 border-red-100 animate-in slide-in-from-top-2 duration-300">
              <p className="text-red-600 font-black uppercase tracking-widest text-[10px] text-center">{error}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Search Tips</p>
              <ul className="text-[10px] font-bold text-slate-500 space-y-2 uppercase tracking-wide">
                <li>• Use partial names (e.g. "Mall")</li>
                <li>• Search by street address</li>
                <li>• Search by building name</li>
              </ul>
            </div>
            <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100">
              <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-2">Data Saving</p>
              <p className="text-[10px] font-bold text-emerald-700 uppercase tracking-wide leading-relaxed">
                Searching downloads only the specific site data you need, saving mobile data.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GlobalSearch;
