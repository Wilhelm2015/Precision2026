import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.error("FATAL: Missing Supabase Environment Variables. Ensure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set in the environment.");
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
